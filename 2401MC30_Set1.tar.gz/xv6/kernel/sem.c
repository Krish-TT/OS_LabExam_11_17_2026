#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "vm.h"
#include "defs.h"

#define NSEMS 8

struct semaphore {
  int value;
  int in_use;
};

static struct {
  struct spinlock lock;
  struct semaphore entries[NSEMS];
} semaphores;

void
seminit(void)
{
  initlock(&semaphores.lock, "semaphores");
  for (int i = 0; i < NSEMS; i++) {
    semaphores.entries[i].value = 0;
    semaphores.entries[i].in_use = 0;
  }
}

int
ksem_init(int id, int value)
{
  if (id < 0 || id >= NSEMS || value < 0)
    return -1;

  acquire(&semaphores.lock);
  semaphores.entries[id].value = value;
  semaphores.entries[id].in_use = 1;
  release(&semaphores.lock);
  return 0;
}

int
ksem_wait(int id)
{
  if (id < 0 || id >= NSEMS)
    return -1;

  acquire(&semaphores.lock);
  if (!semaphores.entries[id].in_use) {
    release(&semaphores.lock);
    return -1;
  }

  while (semaphores.entries[id].value == 0) {
    sleep_prepare(&semaphores.entries[id]);
    release(&semaphores.lock);
    sleep();
    acquire(&semaphores.lock);
  }

  semaphores.entries[id].value--;
  release(&semaphores.lock);
  return 0;
}

int
ksem_post(int id)
{
  if (id < 0 || id >= NSEMS)
    return -1;

  acquire(&semaphores.lock);
  if (!semaphores.entries[id].in_use) {
    release(&semaphores.lock);
    return -1;
  }

  semaphores.entries[id].value++;
  wakeup(&semaphores.entries[id]);
  release(&semaphores.lock);
  return 0;
}
