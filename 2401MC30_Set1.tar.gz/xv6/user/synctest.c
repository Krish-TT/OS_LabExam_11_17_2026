#include "kernel/types.h"
#include "user/user.h"

int
main(void)
{
  if (sem_wait(7) != -1 || sem_post(7) != -1 || sem_init(8, 0) != -1 || sem_init(0, -1) != -1) {
    printf("Invalid semaphore arguments\n");
    exit(1);
  }

  if (sem_init(0, 1) < 0 || sem_init(1, 0) < 0 || sem_init(2, 0) < 0) {
    printf("sem_init failed\n");
    exit(1);
  }

  for (int i = 0; i < 3; i++) {
    int pid = fork();
    if (pid < 0) {
      printf("fork failed\n");
      exit(1);
    }
    if (pid == 0) {
      for (int n = 0; n < 5; n++) {
        if (sem_wait(i) < 0) {
          printf("sem_wait failed\n");
          exit(1);
        }
        printf("%c", 'A' + i);
        if (sem_post((i + 1) % 3) < 0) {
          printf("sem_post failed\n");
          exit(1);
        }
      }
      exit(0);
    }
  }

  for (int i = 0; i < 3; i++)
    wait(0);
  printf("\nDone\n");
  exit(0);
}
