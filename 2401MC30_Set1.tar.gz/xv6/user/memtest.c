#include "kernel/types.h"
#include "user/user.h"

#define PAGE_SIZE 4096

volatile int global_value = 42;

int
main(void)
{
  int ready[2], release[2];
  int child_pa;
  int parent_pa;
  int failed = 0;
  int baseline;
  int pid;

  printf("free pages at start: %d\n", freepages());
  if (sbrk(10 * PAGE_SIZE) == (char *)-1) {
    printf("sbrk failed\n");
    exit(1);
  }
  printf("free pages after sbrk(10 pages): %d\n", freepages());
  parent_pa = va2pa((uint64)&global_value);
  printf("VA=%p PA=0x%x\n",
         (void *)&global_value, parent_pa);
  if (parent_pa == -1 || va2pa(0x7fffffff) != -1) {
    printf("translation failed\n");
    failed = 1;
  } else {
    printf("va2pa(0x7fffffff): -1\n");
  }
  if (pipe(ready) < 0 || pipe(release) < 0) {
    printf("pipe failed\n");
    exit(1);
  }
  baseline = freepages();
  pid = fork();
  if (pid < 0) {
    printf("fork failed\n");
    exit(1);
  }
  if (pid == 0) {
    close(ready[0]);
    close(release[1]);
    child_pa = va2pa((uint64)&global_value);
    printf("child: VA=%p PA=0x%x\n",
           (void *)&global_value, child_pa);
    if (write(ready[1], &child_pa, sizeof(child_pa)) != sizeof(child_pa)) {
      printf("child report failed\n");
      exit(1);
    }
    close(ready[1]);
    read(release[0], &pid, 1);
    close(release[0]);
    exit(0);
  }close(ready[1]);
  
  if (read(ready[0], &child_pa, sizeof(child_pa)) != sizeof(child_pa)) {
    printf("child report missing\n");
    exit(1);
  }
  printf("free pages after fork: %d\n", freepages());
  parent_pa = va2pa((uint64)&global_value);
  printf("parent: VA=%p PA=0x%x\n",
         (void *)&global_value, parent_pa);
  printf("child PA: 0x%x\n", child_pa);
  if (child_pa == -1 || child_pa == parent_pa) {
    printf("ERROR: Invalid PA\n");
    failed = 1;
  }

  write(release[1], "x", 1);
  close(release[1]);

  if (wait(0) < 0) {
    printf("wait failed\n");
    failed = 1;
  }
  printf("free pages after child reap: %d\n", freepages());

  if (freepages() != baseline){
    printf("ERROR");
    failed = 1;
  }
  close(ready[0]);
  close(release[0]);
  exit(failed);
}
