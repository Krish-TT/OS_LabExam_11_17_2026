Name: Krish Seksaria
Roll Number: 2401MC30
Set: 1(2Pm to 4Pm)

Question 1
Added an eight-entry counting semaphore table in sem.c, protected by a spinlock.
Created sem_init, sem_wait, and sem_post system calls. waits sleep and recheck after wakeup.
Added synctest.c to verify invalid arguments and strict A B C ordering for five rounds.
Runtime result: ABCABC.. as expected

Question 2
Added locked free-page accounting to kernel/kalloc.c and exposed it through freepages().
Added va2pa function to translate user VAs, rejecting invalid or "non-user" pages.
Added memtest.c to test sbrk, invalid translation, fork address separation, and reaping.
Runtime result: 
    free pages at start: 32535
    free pages after sbrk(10 pages): 32525
    VA=0x0000000000001000 PA=0x87F25000
    va2pa(0x7fffffff): -1
    child: VA=0x0000000000001000 PA=0x87F1C000
    free pages after fork: 32503
    parent: VA=0x0000000000001000 PA=0x87F25000
    child PA: 0x87F1C000
    free pages after child reap: 32523

Run using " make qemu CPUS=1 " as multiple cores of CPU are used by default which makes the result ambigious otherwise
